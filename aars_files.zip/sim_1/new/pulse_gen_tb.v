`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 23.09.2026 16:12:16
// Design Name: 
// Module Name: pulse_gen_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pulse_gen_tb(

    );
    
    reg start,rst,clk;
    wire si;
    reg[1:0] mode0,mode1,mode2,mode3;
    wire pulse0,pulse1,pulse2,pulse3;
    
    always #5 clk= ~clk;
    integer count0,count1,count2,count3;
    
    initial begin
        mode0 = 2'b00;
        mode1 = 2'b01;
        mode2 = 2'b10;
        mode3 = 2'b11;
        
        rst = 1'b1;
        #1;
        clk = 1'b0;
        #10;
        rst = 1'b0;
        start = 1'b1;
        count0= 0;
        count1= 0;
        count2= 0;
        count3= 0;
        
        
    end
    
    always @(posedge pulse0) begin
        count0 = count0 + 1;
    end
    
    always @(posedge pulse1) begin
        count1 = count1 + 1;
    end
    
    always @(posedge pulse2) begin
        count2 = count2 + 1;
    end
    
    always @(posedge pulse3) begin
        count3 = count3 + 1;
    end
    
    wire SI;
    pulse_gen dut1(start,rst,clk,mode0,pulse0);
    pulse_gen dut2(start,rst,clk,mode1,pulse1);
    pulse_gen dut3(start,rst,clk,mode2,pulse2);
    pulse_gen dut4(start,rst,clk,mode3,pulse3);
    top dut5(clk,rst,start,mode3,SI);
    
endmodule
