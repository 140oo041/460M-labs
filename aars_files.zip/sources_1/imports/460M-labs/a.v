module a(input pulse, clk, rst, output si,output wire [15:0] bcd);

    localparam S0 = 2'b00, S1 = 2'b01, S2 = 2'b11;
    wire co1,co2,co3;
    wire carry;

    
    decadeCounter d1(pulse & (bcd != {4{4'd9}}),rst, clk, bcd[3:0], co1);
    decadeCounter d2(co1,rst, clk, bcd[7:4], co2);
    decadeCounter d3(co2,rst, clk, bcd[11:8], co3);
    decadeCounter d4(co3,rst, clk, bcd[15:12], carry);
    assign si = (bcd == {4{4'd9}}) ? 1'b1 : 1'b0;



    // reg [1:0] state;
    // wire [1:0] next_state;

    // always @(posedge clk) begin
    //     if(rst) begin
    //         state <= 0;
    //     end else begin
    //         state <= next_state;
    //     end
    // end

    // wire add;

    // always @(*) begin
    //     case(state)
    //         S0: next_state = pulse ? S1 : S0; add = 0;
    //         S1: next_state = pulse ? S1 : S2;
    //         S2: next_state = pulse ? S1 : S2;
    //         default: next_state = S0;
    //     endcase
    // end

endmodule

module decadeCounter(input en,input rst, input clk, output reg[3:0] count, output wire carry);
    assign carry = (count == 9 && en) ? 1 : 0;
    
    always @(posedge clk) begin
        if(rst) count <= 0;    
        else if(en) begin
            if(count == 9) begin
                count <= 0;

            end else begin
                count <= count + 1;
            end
        end else count <= count;
    end
endmodule
