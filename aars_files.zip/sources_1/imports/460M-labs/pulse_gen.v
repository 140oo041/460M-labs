module NpulsesPerSec(input clk,rst,en, input [31:0] step_delay, output reg pulse);
    reg [31:0] counter;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            counter <= 0;
            pulse <= 0;
        end else if (en) begin
            if (counter >= step_delay-1) begin
                pulse <= 1; // Toggle pulse
                counter <= 0; // Reset counter
            end else begin
                pulse <= 0;
                counter <= counter + 1; // Increment counter
            end
        end else begin
            pulse <= 0; // Ensure pulse is low when not started
        end
    end

endmodule

module pulse_gen(
    input start,rst,clk,
    input [1:0] mode,
    output wire pulse
);
    localparam frequency = 100_000;

    localparam walk_mode = 2'b00;
    localparam jog_mode = 2'b01;
    localparam run_mode = 2'b10;
    localparam hybrid_mode = 2'b11;

    // localparam frequency = 1000000; // 1 MHz

    localparam walk_step_delay = frequency / 32; // frequency * step_delay = 32 Hz
    localparam jog_step_delay = frequency / 64; // frequency * step_delay = 20 Hz
    localparam run_step_delay = frequency / 96; // frequency * step_delay = 10 Hz
    // hybrid_step_delay is compiled based on ticks
    reg[31:0] step_delay;



    always @(posedge clk or posedge rst) begin
        case(mode)
            walk_mode: step_delay <= walk_step_delay; // frequency * step_delay = 32 Hz
            jog_mode: step_delay <= jog_step_delay; // frequency * step_delay = 20 Hz
            run_mode: step_delay <= run_step_delay; // frequency * step_delay = 10 Hz
            hybrid_mode: step_delay <= hybrid_step_delay(ticks); // frequency *
            default:
                    step_delay <= frequency; // frequency * step_delay = 5 Hz
        endcase
    end

    reg [31:0] tick_counter;
    reg [7:0] ticks;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tick_counter <= 0;
            ticks <= 0;
        end else if (start) begin
            if (tick_counter >= frequency) begin
                ticks <= ticks + 1; // Increment ticks
                tick_counter <= 0; // Reset tick_counter
            end else tick_counter <= tick_counter + 1; // Increment tick_counter
        end else begin
            tick_counter <= 0; // Ensure tick_counter is low when not started
        end
    end

    NpulsesPerSec pulse_generator(.clk(clk), .rst(rst), .en(start && (step_delay != 0 && step_delay != frequency)), .step_delay(step_delay), .pulse(pulse));
    
    function [31:0] hybrid_step_delay(input [7:0] idx);
//    localparam frequency = 100_000_000; // 1 MHz
    begin
        case (idx)
            8'd0:    hybrid_step_delay = frequency / 18;
            8'd1:    hybrid_step_delay = frequency / 35;
            8'd2:    hybrid_step_delay = frequency / 57;
            8'd3:    hybrid_step_delay = frequency / 24;
            8'd4:    hybrid_step_delay = frequency / 71;
            8'd5:    hybrid_step_delay = frequency / 39;
            8'd6:    hybrid_step_delay = frequency / 22;
            8'd7:    hybrid_step_delay = frequency / 30;
            8'd8:    hybrid_step_delay = frequency / 36;
            default: begin
                        if(idx >= 9 && idx <= 70) begin
                            hybrid_step_delay = frequency / 73; // frequency * step_delay = 20 Hz, 10 Hz, 5 Hz
                        end 
                        else if(idx >= 71 && idx <= 79) begin
                            hybrid_step_delay = frequency / 41; // frequency * step_delay = 20 Hz, 10 Hz, 5 Hz
                        end 
                        else if(idx >= 80 && idx <= 143) begin
                            hybrid_step_delay = frequency / 111; // frequency * step_delay = 20 Hz, 10 Hz, 5 Hz
                        end 
                        else begin
                            hybrid_step_delay = frequency; // Default to hybrid mode if ticks is invalid
                        end
                    end
        endcase
    end
endfunction

endmodule

