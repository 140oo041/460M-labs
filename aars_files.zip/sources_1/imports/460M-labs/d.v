module d(input wire[15:0] stepsPerSec, input wire tick,clk,rst,output reg [15:0] accumulator);

    reg [11:0] consecutiveSeconds;
    
    always @(posedge clk)begin
        if(rst) begin consecutiveSeconds <= 0; end
        else if(tick) begin
            if(|stepsPerSec[15:6]) begin
                consecutiveSeconds <= consecutiveSeconds + 1;
            end else consecutiveSeconds <= 0;
        end else consecutiveSeconds <= consecutiveSeconds;
    end
    
    always @(posedge clk) begin
        if(rst) begin accumulator <= 0; end
        else if(tick && (consecutiveSeconds >= 59)) begin
            if((consecutiveSeconds == 59) && |stepsPerSec[15:6]) accumulator <= accumulator + 60;
            else if (|stepsPerSec[15:6])accumulator <= accumulator + 1;
        end else accumulator <= accumulator;
    end
    

    



endmodule

module tickCounter(input clk, input rst, input tick, output reg[11:0] count, output wire carry);
    assign carry = (count == 999) ? 1 : 0;

    always @(posedge clk) begin
        if(rst) begin
            count <= 0;
        end else if(tick) begin
            if(count == 999) begin
                count <= 0;
            end else begin
                count <= count + 1;
            end
        end else begin
            count <= count;
        end
    end
endmodule

module stepCounter(input clk, input rst, input pulse, output reg[15:0] count, output wire carry);
    assign carry = (count == 16'hFFFF) ? 1 : 0;

    always @(posedge clk) begin
        if(rst) begin
            count <= 0;
        end else if(pulse) begin
                count <= count + 1;
        end
        else begin
            count <= count;
        end
    end
endmodule