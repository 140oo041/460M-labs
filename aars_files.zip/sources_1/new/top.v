`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 25.09.2026 13:19:50
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top(
    input clk,rst,start,input [1:0] mode, output SI
    );
    wire pulse;
    
    wire[15:0] steps;
    wire steps_carry;
    
    wire[11:0] ticks;
    wire ticks_carry;
    
    wire[15:0] stepsPerSec;
    
    wire tick;
    
    pulse_gen pulse_gen_mod(start,rst,clk,
mode,
pulse
);
    stepCounter step_counter_mod(clk,rst,pulse,steps,steps_carry);
    tick_gen tick_gen_mod(clk,rst,tick);
    tickCounter tick_counter_mod(clk,rst,tick,ticks,ticks_carry);
    stepsPerSec stepsPerSec_mod(pulse,tick,clk,rst,stepsPerSec);
    
    wire [15:0] a_out;
    a a_mod (pulse,clk,rst,SI,a_out);
    
    wire [7:0] b_out;
    b b_mod (steps,b_out);
    
    wire [3:0] c_out;
    c c_mod (stepsPerSec, tick,clk,rst,ticks,c_out);
    
    wire [15:0] d_out;
    d d_mod(stepsPerSec,tick,clk,rst,d_out);
endmodule

module hextossg(
    input [3:0] hex,
    output reg[6:0] out
);

    always @(*)
        case (hex)
            4'h0 : out = ~(7'b01111_11);
            4'h1 : out =  ~(7'b0000_110);
            4'h2 : out = ~7'b1011_011;
            4'h3 : out = ~7'b1001_111;
            4'h4 : out = ~7'b1100_110;
            4'h5 : out = ~7'b1101_101;
            4'h6 : out = ~7'b1111_101;
            4'h7 : out = ~7'b0000_111;
            4'h8 : out = ~7'b1111_111;
            4'h9 : out = ~7'b1101_111;
            default : out = ~7'b0000_000;
        endcase
        
endmodule

module time_mux_fsm(

    input wire clk,reset,
    input wire [6:0] in0,
    input wire [6:0] in1,
    input wire [6:0] in2,
    input wire [6:0] in3,
    output reg [6:0] out,
    output reg [3:0] an,
    output wire[1:0] current_state_
    );



    reg[1:0] current_state;
    assign current_state_ = current_state;
    reg[1:0] next_state;
    always @(posedge clk or posedge reset) begin
        if(reset) begin
            current_state <= 2'b00;  
            end
        else begin
            current_state <= next_state;
        end   
         end
         
    always @(*) begin
    
        case(current_state) 
            2'b00 : next_state = 2'b01;    
            2'b01 : next_state = 2'b10 ;   
            2'b10 : next_state = 2'b11  ;  
            2'b11 : next_state = 2'b00   ; 
        endcase
        
        case(current_state) 
            2'b00 : out = in0;    
            2'b01 : out = in1; 
            2'b10 : out = in2;
            2'b11 : out = in3;  
        endcase
        
        case(current_state) 
            2'b00 : an = 4'b1110;    
            2'b01 : an = 4'b1101;  
            2'b10 : an = 4'b1011; 
            2'b11 : an = 4'b0111;          
        endcase
    
    end

endmodule
