`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 23.09.2026 17:37:33
// Design Name: 
// Module Name: b
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module b(
    input wire [15:0] steps,output wire [7:0] res
    );
    wire [4:0] intermediate = steps[15:11];
    assign res[3:0] = intermediate[0] ? 4'd5 : 4'd0;
    assign res[7:4] = intermediate[4:1];    
endmodule
