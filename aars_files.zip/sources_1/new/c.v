`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 23.09.2026 17:54:57
// Design Name: 
// Module Name: c
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module c(input wire[15:0] stepsPerSec, input wire tick,clk,rst,input [11:0] tick_cnt,
output reg [3:0] high_activity_ticks
    );
    
    always@(posedge clk or posedge rst) begin
        if(rst) begin  high_activity_ticks <= 0; end
        if(tick) begin
            if(stepsPerSec >= 32 && (tick_cnt < 9)) high_activity_ticks <= high_activity_ticks + 1;
        end
    end
endmodule
